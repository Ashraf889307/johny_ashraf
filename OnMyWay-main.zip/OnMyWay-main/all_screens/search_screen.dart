import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:rider_app/all_widgets/components.dart';
import 'package:rider_app/all_widgets/constants.dart';
import 'package:rider_app/all_widgets/prograss_dialog.dart';
import 'package:rider_app/assistants/request_assistant.dart';
import 'package:rider_app/data_handler/app_data.dart';
import 'package:rider_app/models/address.dart';
import 'package:rider_app/models/place_predications.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({Key? key}) : super(key: key);

  @override
  _SearchScreenState createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  var pickUpController = TextEditingController();
  var dropOffController = TextEditingController();
  List<PlacePredication> placePredicationsList = [];

  @override
  Widget build(BuildContext context) {
    String placeAddress =
        Provider.of<AppData>(context).pickUpLocation!.placeName.toString();
    pickUpController.text = placeAddress;

    return Consumer<AppData>(
      builder: (context,model,child){
        return Scaffold(
          body: Column(
            children: [
              Card(
                shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                elevation: 10,
                child: Container(
                  height: 215,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(15),
                      color: white,
                      boxShadow: const []),
                  child: Padding(
                    padding: const EdgeInsets.only(
                        left: 25, top: 25, right: 25, bottom: 20),
                    child: Column(
                      children: [
                        const SizedBox(
                          height: 5.0,
                        ),
                        Stack(
                          children: [
                            GestureDetector(
                              onTap: () {
                                Navigator.pop(context);
                              },
                              child: const Icon(Icons.arrow_back_ios_sharp),
                            ),
                            const Center(
                                child: Text(
                                  'Set place to go',
                                  style: TextStyle(
                                      fontSize: 18.0, fontFamily: 'Brand-Bold'),
                                ))
                          ],
                        ),
                        const SizedBox(
                          height: 16.0,
                        ),
                        Row(
                          children: [
                            Image.asset(
                              'assets/images/pickicon.png',
                              height: 16,
                              width: 16,
                            ),
                            const SizedBox(
                              width: 18,
                            ),
                            Expanded(
                              child: Container(
                                decoration: BoxDecoration(
                                    color: Colors.grey[400],
                                    borderRadius: BorderRadius.circular(5)),
                                child: Padding(
                                  padding: const EdgeInsets.all(3.0),
                                  child: TextField(
                                    controller: pickUpController,
                                    decoration: InputDecoration(
                                      hintText: 'PickUp Location',
                                      fillColor: Colors.grey[400],
                                      filled: true,
                                      border: InputBorder.none,
                                      isDense: true,
                                      contentPadding: const EdgeInsets.only(
                                          left: 11.0, top: 8.0, bottom: 8.0),
                                    ),
                                  ),
                                ),
                              ),
                            )
                          ],
                        ),
                        const SizedBox(
                          height: 10.0,
                        ),
                        Row(
                          children: [
                            Image.asset(
                              'assets/images/desticon.png',
                              height: 16,
                              width: 16,
                            ),
                            const SizedBox(
                              width: 18,
                            ),
                            Expanded(
                              child: Container(
                                decoration: BoxDecoration(
                                    color: Colors.grey[400],
                                    borderRadius: BorderRadius.circular(5)),
                                child: Padding(
                                  padding: const EdgeInsets.all(3.0),
                                  child: TextField(
                                    onChanged: (String valPlace) {
                                      findPlace(valPlace);
                                    },
                                    controller: dropOffController,
                                    decoration: InputDecoration(
                                      hintText: 'Where to?',
                                      fillColor: Colors.grey[400],
                                      filled: true,
                                      border: InputBorder.none,
                                      isDense: true,
                                      contentPadding: const EdgeInsets.only(
                                          left: 11.0, top: 8.0, bottom: 8.0),
                                    ),
                                  ),
                                ),
                              ),
                            )
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              // const SizedBox(height: 10,),
              (placePredicationsList.isNotEmpty)
                  ? Expanded(
                child: SingleChildScrollView(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        vertical: 8.0, horizontal: 16.0),
                    child: ListView.separated(
                      padding: const EdgeInsets.all(0.0),
                      itemBuilder: (context, index) {
                        return PredictionTile(
                          placePredication: placePredicationsList[index],
                        );
                      },
                      separatorBuilder: (BuildContext context, int index) {
                        return Padding(
                          padding:
                          const EdgeInsets.symmetric(horizontal: 28.0),
                          child: buildDivider(),
                        );
                      },
                      itemCount: placePredicationsList.length,
                      shrinkWrap: true,
                      physics: const ClampingScrollPhysics(),
                    ),
                  ),
                ),
              )
                  : Container()
            ],
          ),
        );
      },

    );
  }

  ///This function to get place which you search it
  void findPlace(String placeName) async {
    if (placeName.length > 1) {
      String autoCompleteUrl =
          'https://maps.googleapis.com/maps/api/place/autocomplete/json?input=$placeName&key=$mapKey&sessiontoken=151511&components=country:eg';

      var responseAutoCompleteUrl =
          await RequestAssistant.getRequest(autoCompleteUrl);
      if (responseAutoCompleteUrl == 'failed') {
        return;
      }
      if (responseAutoCompleteUrl['status'] == 'OK') {
        var predictions = responseAutoCompleteUrl['predictions'];
        var placesList = (predictions as List)
            .map((e) => PlacePredication.fromJson(e))
            .toList();
        setState(() {
          placePredicationsList = placesList;
        });
      }
    }
  }
}

class PredictionTile extends StatelessWidget {
  final PlacePredication? placePredication;
  const PredictionTile({Key? key, this.placePredication}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialButton(
      padding: const EdgeInsets.all(0.0),
      onPressed: () {
        getPlaceAddressDetails(placePredication?.place_id, context);
      },
      child: Column(
        children: [
          const SizedBox(
            width: 10.0,
          ),
          Row(
            children: [
              Image.asset(
                'assets/images/redmarker.png',
                height: 20,
                width: 20,
              ),
              //const Icon(Icons.add_location),
              const SizedBox(
                width: 14.0,
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(
                      height: 8.0,
                    ),
                    Text(
                      '${placePredication?.main_text}',
                      style: const TextStyle(fontSize: 16.0),
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(
                      height: 2.0,
                    ),
                    Text(
                      '${placePredication?.secondary_text}',
                      style: const TextStyle(fontSize: 12.0, color: grey),
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(
                      height: 8.0,
                    ),
                  ],
                ),
              )
            ],
          ),
          const SizedBox(
            width: 10.0,
          ),
        ],
      ),
    );
  }

  void getPlaceAddressDetails(placeId, context) async {
    showDialog(
        context: context,
        builder: (BuildContext ctx) => ProgressDialog(
              message: 'Loading...Please Wait',
            ));
    String placeDetailsUrl =
        'https://maps.googleapis.com/maps/api/place/details/json?&place_id=$placeId&key=$mapKey';
    var responsePlaceDetailsUrl =
        await RequestAssistant.getRequest(placeDetailsUrl);
    Navigator.pop(context);
    if (responsePlaceDetailsUrl == 'failed') {
      return;
    }
    if (responsePlaceDetailsUrl['status'] == 'OK') {
      Address address = Address();
      address.placeName = responsePlaceDetailsUrl['result']['name'];
      address.placeId = placeId;
      address.latitude =
          responsePlaceDetailsUrl['result']['geometry']['location']['lat'];
      address.longitude =
          responsePlaceDetailsUrl['result']['geometry']['location']['lng'];
      Provider.of<AppData>(context, listen: false)
          .updateDropOfLocationAddress(address);
      print('this is drop off location');
      print('this is drop off location>>>${address.placeName}');

      Navigator.pop(context, 'obtainDirections');
    }
  }
}
