import 'dart:async';

import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_dialogs/flutter_dialogs.dart';
import 'package:flutter_geofire/flutter_geofire.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:provider/provider.dart';
import 'package:rider_app/all_screens/login_screen.dart';
import 'package:rider_app/all_screens/search_screen.dart';
import 'package:rider_app/all_widgets/components.dart';
import 'package:rider_app/all_widgets/constants.dart';
import 'package:rider_app/all_widgets/noDriverAvaliableDialog.dart';
import 'package:rider_app/all_widgets/prograss_dialog.dart';
import 'package:rider_app/assistants/assistan_methods.dart';
import 'package:rider_app/data_handler/app_data.dart';
import 'package:rider_app/main.dart';
import 'package:rider_app/models/direct_details.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:location/location.dart' as k;

class MainScreen extends StatefulWidget {
  static const String idScreen = 'mainScreen';

  MainScreen({Key? key}) : super(key: key);
  @override
  _MainScreenState createState() => _MainScreenState();
}

Completer<GoogleMapController> _controllerGoogleMap = Completer();
GoogleMapController? googleMapController;
var _kGooglePlex = const CameraPosition(
  target: LatLng(37.42796133580664, -122.085749655962),
  zoom: 14.4746,
);
GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
DirectionsDetails? tripDirectionsDetails;
List<LatLng> plineCoordinates = [];
Set<Polyline> polylinSet = {};

Position? currentPosition;
var geolocator = Geolocator();
double bottomPaddingOfMap = 0.0;
Set<Marker> markersSet = {};
Set<Circle> circlesSet = {};

double rideDetailsContainerHeight = 0;
double requestRideContainerHeight = 0;
double searchContainerHeight = 300.0;
double driverDetailsContainerHeight = 0;

bool drawerOpen = true;
bool nearbyAvailableDriverKeysLoaded = false;
DatabaseReference? rideRequestRef;
var nearByIcon;

String state = 'normal';
StreamSubscription<DatabaseEvent>? rideStreamSubscription;
bool isRequestingPositionDetails = false;

///rider Info
String uName = '';
String uGmail = '';
String uPhone = '';

///theme map

class _MainScreenState extends State<MainScreen> with TickerProviderStateMixin {
  @override
  void initState() {
    // TODO: implement initState
    // super.initState();
    localPosition();
    AssistantMethods.getCurrentOnlineUserInfo();
    getLocationPermission();
  }

  void deleteGeofireMarker() {
    setState(() {
      markersSet
          .removeWhere((element) => element.markerId.value.contains("driver"));
    });
  }

  void getLocationPermission() async {
    var location = k.Location();
    try {
      await location.requestPermission().then((value) {
        setState(() {});
      }); //to lunch location permission popup
    } on PlatformException catch (e) {
      if (e.code == 'PERMISSION_DENIED') {
        print('Permission denied');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    createIconMarker();

    //var mapType=MapType.normal;

    return Scaffold(
      drawer: Container(
        color: white,
        width: 255,
        child: Drawer(
          child: ListView(
            children: [
              SizedBox(
                height: 165,
                child: DrawerHeader(
                  decoration:
                      const BoxDecoration(color: Color.fromRGBO(6, 40, 61, 1)),
                  child: Row(
                    children: [
                      Image.asset(
                        'assets/images/user_icon.png',
                        height: 65,
                        width: 65,
                      ),
                      const SizedBox(
                        width: 16,
                      ),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: 140,
                            child: Text(
                              uName,
                              style: const TextStyle(
                                  fontSize: 16,
                                  fontFamily: 'Brand Bold',
                                  color: Colors.white,
                                  overflow: TextOverflow.ellipsis),
                            ),
                          ),
                          const SizedBox(
                            height: 3,
                          ),
                          Text(
                            uGmail,
                            style: const TextStyle(
                                fontSize: 16,
                                fontFamily: 'Signatra',
                                color: Colors.white),
                          )
                        ],
                      )
                    ],
                  ),
                ),
              ),
              buildDivider(),
              const SizedBox(
                height: 12.0,
              ),
              // const ListTile(
              //   leading: Icon(
              //     Icons.history,
              //   ),
              //   title: Text(
              //     'History',
              //     style: TextStyle(fontSize: 15),
              //   ),
              // ),
              // const ListTile(
              //   leading: Icon(
              //     Icons.person,
              //   ),
              //   title: Text(
              //     'Visit Profile',
              //     style: TextStyle(fontSize: 15),
              //   ),
              // ),
              ListTile(
                leading: const Icon(
                  Icons.phone_android,
                ),
                title: Text(
                  uPhone ?? 'Not Found',
                  style: const TextStyle(fontSize: 15),
                ),
              ),
              GestureDetector(
                onTap: () async {
                  await showPlatformDialog(
                    context: context,
                    builder: (context) => BasicDialogAlert(
                      title: const Text("Log Out"),
                      content: const Text("Are You Sure To Log Out?"),
                      actions: <Widget>[
                        BasicDialogAction(
                          title: Text("Cancel"),
                          onPressed: () {
                            Navigator.pop(context);
                          },
                        ),
                        BasicDialogAction(
                          title: Text("OK"),
                          onPressed: () {
                            FirebaseAuth.instance.signOut();
                            Navigator.pushNamedAndRemoveUntil(context,
                                LoginScreen.idScreen, (route) => false);
                          },
                        ),
                      ],
                    ),
                  );
                },
                child: const ListTile(
                  leading: Icon(
                    Icons.logout,
                  ),
                  title: Text(
                    'Log Out',
                    style: TextStyle(fontSize: 15),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      key: scaffoldKey,
      body: Stack(
        children: [
          GoogleMap(
            markers: markersSet,
            circles: circlesSet,
            polylines: polylinSet,
            padding: EdgeInsets.only(bottom: bottomPaddingOfMap),
            mapType: Provider.of<AppData>(context, listen: false).mapType,
            initialCameraPosition: _kGooglePlex,
            myLocationEnabled: true,
            zoomGesturesEnabled: true,
            zoomControlsEnabled: true,
            myLocationButtonEnabled: true,
            onMapCreated: (GoogleMapController controller) {
              _controllerGoogleMap.complete(controller);
              googleMapController = controller;

              setState(() {
                bottomPaddingOfMap = 300.0;
              });

              localPosition();
            },
          ),
          Positioned(
            top: 100.0,
            left: 21.0,
            child: Container(
              decoration: BoxDecoration(
                  color: white,
                  borderRadius: BorderRadius.circular(22),
                  boxShadow: const [
                    BoxShadow(
                        color: black,
                        spreadRadius: 0.8,
                        blurRadius: 5,
                        offset: Offset(0.7, 0.7))
                  ]),
              child: CircleAvatar(
                backgroundColor: const Color.fromRGBO(26, 77, 50, 0.9),
                child: GestureDetector(
                  onTap: () {
                    switch (
                        Provider.of<AppData>(context, listen: false).mapType) {
                      case MapType.none:
                        // TODO: Handle this case.
                        break;
                      case MapType.normal:
                        // TODO: Handle this case.
                        break;
                      case MapType.satellite:
                        // TODO: Handle this case.
                        break;
                      case MapType.terrain:
                        // TODO: Handle this case.
                        break;
                      case MapType.hybrid:
                        // TODO: Handle this case.
                        break;
                    }
                    showModalBottomSheet(
                        context: context,
                        builder: (context) => Consumer<AppData>(
                              builder: (context, model, child) {
                                return Container(
                                  color: white,
                                  height: 250,
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          const Padding(
                                            padding: EdgeInsets.only(
                                                top: 10.0, left: 15),
                                            child: Text(
                                              'Map Type',
                                              style: TextStyle(
                                                  fontFamily: 'Brand Bold',
                                                  fontSize: 18),
                                            ),
                                          ),
                                          const Spacer(),
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                top: 10.0, right: 15),
                                            child: CircleAvatar(
                                              child: IconButton(
                                                icon: const Icon(
                                                  Icons.cancel,
                                                  color: white,
                                                ),
                                                onPressed: () {
                                                  Navigator.pop(context);
                                                },
                                              ),
                                              backgroundColor: Color.fromRGBO(
                                                  26, 77, 50, 0.7),
                                            ),
                                          ),
                                        ],
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                      ),
                                      const SizedBox(
                                        height: 20,
                                      ),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceAround,
                                        children: [
                                          Column(
                                            children: [
                                              GestureDetector(
                                                onTap: () {
                                                  setState(() {
                                                    Provider.of<AppData>(
                                                            context,
                                                            listen: false)
                                                        .updateGoogleMapsShape(
                                                            MapType.satellite);
                                                  });
                                                },
                                                child: Card(
                                                  elevation: 2,
                                                  shape: RoundedRectangleBorder(
                                                      side: BorderSide(
                                                        color: Provider.of<AppData>(
                                                                        context,
                                                                        listen:
                                                                            false)
                                                                    .mapType ==
                                                                MapType
                                                                    .satellite
                                                            ? Colors
                                                                .green.shade900
                                                            : white,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              9)),
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets.all(
                                                            8.0),
                                                    child: Image.asset(
                                                      'assets/images/globe.png',
                                                      height: 50,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              const SizedBox(
                                                height: 8,
                                              ),
                                              const Text(
                                                'Satellite',
                                                style: TextStyle(
                                                    fontFamily: 'Brand-Regular',
                                                    fontSize: 18),
                                              ),
                                            ],
                                          ),
                                          Column(
                                            children: [
                                              GestureDetector(
                                                onTap: () {
                                                  setState(() {
                                                    Provider.of<AppData>(
                                                            context,
                                                            listen: false)
                                                        .updateGoogleMapsShape(
                                                            MapType.terrain);
                                                  });
                                                },
                                                child: Card(
                                                  elevation: 2,
                                                  shape: RoundedRectangleBorder(
                                                      side: BorderSide(
                                                        color: Provider.of<AppData>(
                                                                        context,
                                                                        listen:
                                                                            false)
                                                                    .mapType ==
                                                                MapType.terrain
                                                            ? Colors
                                                                .green.shade900
                                                            : white,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              9)),
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets.all(
                                                            8.0),
                                                    child: Image.asset(
                                                      'assets/images/map_shape_1.png',
                                                      height: 50,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              const SizedBox(
                                                height: 8,
                                              ),
                                              const Text(
                                                'Hybrid',
                                                style: TextStyle(
                                                    fontFamily: 'Brand-Regular',
                                                    fontSize: 18),
                                              ),
                                            ],
                                          ),
                                          Column(
                                            children: [
                                              GestureDetector(
                                                onTap: () {
                                                  setState(() {
                                                    Provider.of<AppData>(
                                                            context,
                                                            listen: false)
                                                        .updateGoogleMapsShape(
                                                            MapType.normal);
                                                  });
                                                },
                                                child: Card(
                                                  shape: RoundedRectangleBorder(
                                                      side: BorderSide(
                                                        color: Provider.of<AppData>(
                                                                        context,
                                                                        listen:
                                                                            false)
                                                                    .mapType ==
                                                                MapType.normal
                                                            ? Colors
                                                                .green.shade900
                                                            : white,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              9)),
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets.all(
                                                            8.0),
                                                    child: Image.asset(
                                                      'assets/images/map_shape_2.png',
                                                      height: 50,
                                                    ),
                                                  ),
                                                  elevation: 2,
                                                ),
                                              ),
                                              const SizedBox(
                                                height: 8,
                                              ),
                                              const Text(
                                                'Normal',
                                                style: TextStyle(
                                                  fontFamily: 'Brand-Regular',
                                                  fontSize: 18,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                );
                              },
                            ));
                  },
                  child: const Icon(
                    Icons.map_sharp,
                    color: white,
                  ),
                ),
                radius: 20,
              ),
            ),
          ),
          Positioned(
            top: 38.0,
            left: 22.0,
            child: GestureDetector(
              onTap: () {
                if (drawerOpen) {
                  scaffoldKey.currentState!.openDrawer();
                } else {
                  restApp();
                }
              },
              child: Container(
                decoration: BoxDecoration(
                    color: white,
                    borderRadius: BorderRadius.circular(22),
                    boxShadow: const [
                      BoxShadow(
                          color: black,
                          spreadRadius: 0.5,
                          blurRadius: 6.0,
                          offset: Offset(0.7, 0.7))
                    ]),
                child: CircleAvatar(
                  backgroundColor: const Color.fromRGBO(26, 77, 50, 0.9),
                  child: drawerOpen
                      ? Image.asset(
                          'assets/images/menue.png',
                          height: 50,
                          width: 25,
                        )
                      : Icon(Icons.close),

                  // Icon(
                  //   drawerOpen ? Icons.menue : Icons.close,
                  //   color: white,
                  // ),
                  radius: 20,
                ),
              ),
            ),
          ),
          Positioned(
            left: 0.0,
            right: 0.0,
            bottom: 0.0,
            child: AnimatedSize(
              vsync: this,
              curve: Curves.bounceIn,
              duration: const Duration(milliseconds: 160),
              child: Container(
                height: searchContainerHeight,
                decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(18.0),
                        topRight: Radius.circular(18)),
                    boxShadow: [
                      BoxShadow(
                          color: Colors.black,
                          blurRadius: 6,
                          spreadRadius: 0.5,
                          offset: Offset(0.7, 0.7))
                    ]),
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 24.0, vertical: 18),
                  child: Column(
                    children: [
                      // const SizedBox(
                      //   height: 6,
                      // ),
                      // const Text(
                      //   'Hi there',
                      //   style: TextStyle(fontSize: 12),
                      // ),
                      Row(
                        children: const [
                          //Lottie.asset('assets/images/whereTo.json', height: 70),
                          Text(
                            'Where to?',
                            style: TextStyle(
                                fontSize: 20, fontFamily: 'Brand-Bold'),
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 20,
                      ),

                      GestureDetector(
                        onTap: () async {
                          var res = await Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const SearchScreen(),
                            ),
                          );
                          if (res == 'obtainDirections') {}
                        },
                        child: Container(
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(5),
                              boxShadow: const [
                                BoxShadow(
                                    color: Colors.black54,
                                    blurRadius: 6.0,
                                    spreadRadius: 0.5,
                                    offset: Offset(0.7, 0.7))
                              ]),
                          child: Padding(
                            padding: const EdgeInsets.all(12.0),
                            child: Row(
                              children: [
                                Icon(
                                  Icons.search,
                                  color: Colors.grey.shade900,
                                ),
                                const SizedBox(
                                  width: 10,
                                ),
                                const Text('Search a place to go')
                              ],
                            ),
                          ),
                        ),
                      ),

                      const SizedBox(
                        height: 24,
                      ),
                      Row(
                        children: [
                          const Icon(
                            Icons.home,
                            color: Color.fromRGBO(26, 77, 50, 0.9),
                          ),
                          const SizedBox(
                            width: 12,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(
                                width: 270,
                                child: Text(
                                  Provider.of<AppData>(context)
                                          .pickUpLocation
                                          ?.placeName ??
                                      'Please Wait...',
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 1,
                                  softWrap: true,
                                ),
                              ),
                              const SizedBox(
                                height: 4.0,
                              ),
                              const Text(
                                'Your living home address',
                                style: TextStyle(
                                    color: Colors.black54, fontSize: 12),
                              )
                            ],
                          )
                        ],
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      buildDivider(),
                      const SizedBox(
                        height: 16,
                      ),
                      Row(
                        children: [
                          const Icon(
                            Icons.work,
                            color: Color.fromRGBO(26, 77, 50, 0.9),
                          ),
                          const SizedBox(
                            width: 12,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: const [
                              Text('Add Work'),
                              SizedBox(
                                height: 4.0,
                              ),
                              Text(
                                'Your Office address',
                                style: TextStyle(
                                    color: Colors.black54, fontSize: 12),
                              )
                            ],
                          )
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            bottom: 0.0,
            left: 0.0,
            right: 0.0,
            child: Container(
              height: driverDetailsContainerHeight,
              decoration: const BoxDecoration(
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(16.0),
                      topRight: Radius.circular(16.0)),
                  color: white,
                  boxShadow: [
                    BoxShadow(
                      spreadRadius: 0.5,
                      blurRadius: 16.0,
                      color: black54,
                      offset: Offset(0.7, 0.7),
                    )
                  ]),
              child: Padding(
                padding: const EdgeInsets.symmetric(
                    vertical: 18.0, horizontal: 24.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(
                      height: 6.0,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          rideStatus,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                              fontSize: 20.0, fontFamily: 'Brand-Bold'),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 22.0,
                    ),
                    const Divider(
                      height: 2,
                      thickness: 2,
                    ),
                    const SizedBox(
                      height: 22.0,
                    ),
                    Row(
                      children: [
                        Image.asset(
                          'assets/images/user_icon.png',
                          height: 55,
                          width: 55,
                        ),
                        const SizedBox(
                          width: 5,
                        ),
                        Column(
                          children: [
                            Text(
                              carDetailsDriver,
                              style: const TextStyle(color: grey),
                            ),
                            Text(
                              driverName,
                              style: const TextStyle(fontSize: 20),
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 22.0,
                    ),
                    const Divider(
                      height: 2,
                      thickness: 2,
                    ),
                    const SizedBox(
                      height: 22.0,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 20.0),
                          child: MaterialButton(
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(5.0)),
                            onPressed: () async {
                              launch(('tel://$driverPhone'));
                            },
                            color: Color.fromRGBO(26, 77, 50, 0.7),
                            child: Padding(
                              padding:
                                  const EdgeInsets.symmetric(vertical: 10.0),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceAround,
                                children: const [
                                  Icon(
                                    Icons.call,
                                    size: 26.0,
                                    color: white,
                                  ),
                                  SizedBox(
                                    width: 10,
                                  ),
                                  Text(
                                    'Call Driver',
                                    style: TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.bold,
                                        color: white),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        )
                      ],
                    )
                  ],
                ),
              ),
            ),
          )
        ],
      ),
    );
  }

  void initGeoFireListener() {
    Geofire.initialize("availableDrivers");
    //
    Geofire.queryAtLocation(
            currentPosition!.latitude, currentPosition!.longitude, 10)
        ?.listen((map) {
      print(map);
      if (map != null) {
        var callBack = map['callBack'];
      }

      setState(() {});
      //
    });
  }

  void createIconMarker() {
    if (nearByIcon == null) {
      ImageConfiguration imageConfiguration = createLocalImageConfiguration(
        context,
        size: const Size(2, 2),
      );
      BitmapDescriptor.fromAssetImage(
              imageConfiguration, "assets/images/car_ios.png")
          .then((value) {
        nearByIcon = value;
      });
    }
  }

  restApp() {
    setState(() {
      requestRideContainerHeight = 0;
      drawerOpen = true;
      searchContainerHeight = 300;
      rideDetailsContainerHeight = 0;
      bottomPaddingOfMap = 230.0;
      polylinSet.clear();
      markersSet.clear();
      circlesSet.clear();
      plineCoordinates.clear();

      statusRide = '';
      driverName = '';
      driverPhone = '';
      carDetailsDriver = '';
      rideStatus = 'Driver is coming';
      driverDetailsContainerHeight = 0.0;
    });

    localPosition();
  }

  void localPosition() async {
    Position position = await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
    );
    currentPosition = position;
    LatLng latLngPosition = LatLng(position.latitude, position.longitude);

    CameraPosition cameraPosition =
        CameraPosition(target: latLngPosition, zoom: 14);

    googleMapController
        ?.animateCamera(CameraUpdate.newCameraPosition(cameraPosition));

    String address =
        await AssistantMethods.searchAssistantAddress(position, context);
    print('this is your address >>>>>>>+ $address');
    initGeoFireListener();
    setState(() {
      uName = '${userCurrentInfo!.name}';
      uGmail = '${userCurrentInfo!.email}';
      uPhone = '${userCurrentInfo!.phone}';
    });
  }

  void displayDriverDetailsContainer() {
    setState(() {
      rideDetailsContainerHeight = 0;
      bottomPaddingOfMap = 280.0;
      requestRideContainerHeight = 0.0;
      driverDetailsContainerHeight = 310.0;
    });
  }

  void noDriverFound() {
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) => const NoDriverAvailableDialog());
  }
}
