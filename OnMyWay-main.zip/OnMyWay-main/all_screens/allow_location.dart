import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:location/location.dart' as k;

import 'login_screen.dart';

class AllowLocation extends StatefulWidget {
  static const String idScreen = 'allowLocation';

  @override
  _AllowLocationState createState() => _AllowLocationState();
}

class _AllowLocationState extends State<AllowLocation> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getLocationPermission();
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: Colors.white,
    );
  }

  void getLocationPermission() async {
    var location = k.Location();
    try {
      await location.requestPermission().then((value) {
        setState(() {
          Navigator.pushNamedAndRemoveUntil(
              context, LoginScreen.idScreen, (route) => false);
        });
      }); //to lunch location permission popup
    } on PlatformException catch (e) {
      if (e.code == 'PERMISSION_DENIED') {
        print('Permission denied');
      }
    }
  }
}
