import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:lottie/lottie.dart';
import 'package:rider_app/all_screens/login_screen.dart';
import 'package:rider_app/all_screens/main_screen.dart';
import 'package:rider_app/all_widgets/components.dart';
import 'package:rider_app/all_widgets/prograss_dialog.dart';
import 'package:rider_app/main.dart';

class RegisterScreen extends StatefulWidget {
  static const String idScreen = 'register';
  static User? user;
  bool _passwordVisible=false;
  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  var nameController = TextEditingController();

  var emailController = TextEditingController();

  var phoneController = TextEditingController();

  var passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: (){
            Navigator.pop(context);
          },
          icon: Icon(
            Icons.arrow_back_ios_sharp,
            color: Colors.black,

          ),
        ),
        elevation: 0,
        backgroundColor: Colors.white,
      ),
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              Lottie.asset('assets/images/logojson.json',
                  height: 170, width: 250),
              const SizedBox(
                height: 30.0,
              ),
              const Text(
                'Register as a Rider',
                style: TextStyle(fontSize: 24, fontFamily: 'Brand Bold'),
              ),
              Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    const SizedBox(
                      height: 1.0,
                    ),
                    Container(
                      decoration: const BoxDecoration(

                      ),
                      child: TextField(

                        cursorColor: Colors.black,
                        controller: nameController,
                        keyboardType: TextInputType.text,
                        decoration:  InputDecoration(
                            border: InputBorder.none,
                            filled: true,
                            fillColor: Colors.grey[300],
                            isDense: true,

                            labelText: 'Name',
                            labelStyle: TextStyle(fontSize: 14,color: Colors.black),
                            hintStyle:
                                TextStyle(color: Colors.grey, fontSize: 10)),
                        style: TextStyle(fontSize: 14),
                      ),
                    ),
                    const SizedBox(
                      height: 15.0,
                    ),
                    Container(
                      decoration: const BoxDecoration(

                      ),
                      child: TextField(
                        cursorColor: Colors.black,
                        controller: emailController,
                        keyboardType: TextInputType.emailAddress,
                        decoration:  InputDecoration(
                            border: InputBorder.none,
                            filled: true,
                            fillColor: Colors.grey[300],
                            isDense: true,
                            labelText: 'Email',
                            labelStyle: TextStyle(fontSize: 14,color: Colors.black),
                            hintStyle:
                                TextStyle(color: Colors.grey, fontSize: 10)),
                        style: TextStyle(fontSize: 14),
                      ),
                    ),
                    const SizedBox(
                      height: 15.0,
                    ),
                    Container(
                      decoration: const BoxDecoration(

                      ),
                      child: TextField(
                        inputFormatters: [

                        ],
                        cursorColor: Colors.black,
                        controller: phoneController,
                        keyboardType: TextInputType.number,
                        decoration:  InputDecoration(
                            border: InputBorder.none,
                            filled: true,
                            fillColor: Colors.grey[300],
                            isDense: true,
                            labelText: 'Phone',
                            labelStyle: TextStyle(fontSize: 14,color: Colors.black),
                            hintStyle:
                                TextStyle(color: Colors.grey, fontSize: 10)),
                        style: TextStyle(fontSize: 14),
                      ),
                    ),
                    const SizedBox(
                      height: 15.0,
                    ),
                    Container(
                      decoration: const BoxDecoration(

                      ),
                      child: TextField(
                        obscuringCharacter: '*',
                        cursorColor: Colors.black,
                        controller: passwordController,
                        obscureText: ! widget._passwordVisible,
                        decoration:  InputDecoration(
                            border: InputBorder.none,
                            filled: true,
                            fillColor: Colors.grey[300],
                            isDense: true,
                            suffixIcon: IconButton(
                              icon: Icon(
                                // Based on passwordVisible state choose the icon
                                widget._passwordVisible
                                    ? Icons.visibility
                                    : Icons.visibility_off,
                                color: Theme.of(context).primaryColorDark,
                              ),
                              onPressed: () {
                                setState(() {
                                  widget._passwordVisible = ! widget._passwordVisible;
                                });
                              },
                            ),

                            labelText: 'Password',
                            labelStyle: TextStyle(fontSize: 14,color: Colors.black),
                            hintStyle:
                                TextStyle(color: Colors.grey, fontSize: 10)),
                        style: TextStyle(fontSize: 14),
                      ),
                    ),
                    const SizedBox(
                      height: 35.0,
                    ),
                    buildButton(
                      elevation: 0.0,
                        color: Colors.black87,
                        textColor: Colors.white,
                        text: 'Create Account',
                        onPressed: (){
                          if (nameController.text.length < 4)
                          {
                            Fluttertoast.showToast(msg: 'Name must');
                          }
                          else if
                          (!emailController.text.contains('@'))
                          {
                            Fluttertoast.showToast(msg: 'email must');
                          }
                          else if
                          (phoneController.text.isEmpty)
                          {
                            Fluttertoast.showToast(msg: 'phone must');
                          }
                          else if
                          (passwordController.text.length < 7)
                          {
                            Fluttertoast.showToast(msg: 'password must');
                          }
                          else {
                            RegisterNewUser(context);
                          }
                        }
                    ),
                    // RaisedButton(
                    //   elevation: 0,
                    //   color: Colors.amber.shade400,
                    //   textColor: Colors.white,
                    //   child: const SizedBox(
                    //     height: 50,
                    //     child: Center(
                    //       child: Text(
                    //         'Create Account',
                    //         style: TextStyle(
                    //             fontSize: 18.0, fontFamily: 'Brand Bold'),
                    //       ),
                    //     ),
                    //   ),
                    //   onPressed: () {
                    //     if (nameController.text.length < 4) {
                    //       Fluttertoast.showToast(msg: 'Name must');
                    //     } else if (!emailController.text.contains('@')) {
                    //       Fluttertoast.showToast(msg: 'email must');
                    //     } else if (phoneController.text.isEmpty) {
                    //       Fluttertoast.showToast(msg: 'phone must');
                    //     } else if (passwordController.text.length < 7) {
                    //       Fluttertoast.showToast(msg: 'password must');
                    //     } else {
                    //       RegisterNewUser(context);
                    //     }
                    //   },
                    //   shape: RoundedRectangleBorder(
                    //     borderRadius: BorderRadius.circular(24),
                    //   ),
                    // ),
                    const SizedBox(
                      height: 20,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text('Already have an account ? ',style:
                          TextStyle(color: Colors.grey),),
                        GestureDetector(
                          onTap: () {
                            Navigator.pushNamedAndRemoveUntil(context,
                                LoginScreen.idScreen, (route) => false);
                          },
                          child: Text('Login Here',style: TextStyle(
                            color: Colors.blue.shade900
                          ),),
                        )
                      ],
                    ),
                    const SizedBox(height: 10,),

                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  final FirebaseAuth? firebaseAuth = FirebaseAuth.instance;

  // ignore: non_constant_identifier_names, avoid_types_as_parameter_names
  void RegisterNewUser(BuildContext context) async {
    showDialog(
        context: context,
        builder: (BuildContext context)=>ProgressDialog(
          message: 'Registering,please wait..',
        ),
        barrierDismissible: false
    );

    final UserCredential firebaseUser = await (firebaseAuth!
        .createUserWithEmailAndPassword(
      email: emailController.text,
      password: passwordController.text,
    )
        .catchError((error) {

      Fluttertoast.showToast(msg: 'error>>>$error');
    }));

    if (firebaseUser != null) {
      Map userDataMap = {
        'name': nameController.text,
        'email': emailController.text,
        'phone': phoneController.text,
        'password': passwordController.text,
      };
      final User? user = firebaseAuth?.currentUser;
      final uid = user?.uid;

      userRef.child(uid!).set(userDataMap);
      Fluttertoast.showToast(msg: 'Done');
      Navigator.pushNamedAndRemoveUntil(
          context, LoginScreen.idScreen, (route) => false);
    } else {
      Navigator.pop(context);

      Fluttertoast.showToast(msg: 'New user account has ');
    }
  }
}
