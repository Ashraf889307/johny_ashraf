import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:lottie/lottie.dart';
import 'package:rider_app/all_screens/register_screen.dart';
import 'package:rider_app/all_widgets/prograss_dialog.dart';
import 'package:rider_app/main.dart';

import 'main_screen.dart';

class LoginScreen extends StatefulWidget {
  static const String idScreen = 'login';

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  var passwordController = TextEditingController();
  var emailController = TextEditingController();
  bool _passwordVisible = false;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              const SizedBox(
                height: 35.0,
              ),
              Lottie.asset('assets/images/logojson.json',
                  height: 250, width: 250),
              const SizedBox(
                height: 20.0,
              ),
              const Text(
                'Login as a Rider',
                style: TextStyle(fontSize: 24, fontFamily: 'Brand Bold'),
              ),
              Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    const SizedBox(
                      height: 25.0,
                    ),
                    Container(
                      decoration: const BoxDecoration(),
                      child: TextField(
                        cursorColor: Colors.black,
                        controller: emailController,
                        keyboardType: TextInputType.emailAddress,
                        decoration: InputDecoration(
                            filled: true,
                            fillColor: Colors.grey[300],
                            isDense: true,
                            labelText: 'Email',
                            border: InputBorder.none,
                            labelStyle: const TextStyle(
                              fontSize: 14,
                              color: Colors.black,
                            ),
                            hintStyle: const TextStyle(
                              color: Colors.grey,
                              fontSize: 10,
                            )),
                        style: const TextStyle(fontSize: 14),
                      ),
                    ),
                    const SizedBox(
                      height: 15.0,
                    ),
                    Container(
                      decoration: const BoxDecoration(),
                      child: TextField(
                        obscuringCharacter: '*',
                        cursorColor: Colors.black,
                        controller: passwordController,
                        obscureText: !_passwordVisible,
                        decoration: InputDecoration(
                            suffixIcon: IconButton(
                              icon: Icon(
                                // Based on passwordVisible state choose the icon
                                _passwordVisible
                                    ? Icons.visibility
                                    : Icons.visibility_off,
                                color: Theme.of(context).primaryColorDark,
                              ),
                              onPressed: () {
                                setState(() {
                                  _passwordVisible = !_passwordVisible;
                                });
                              },
                            ),
                            filled: true,
                            fillColor: Colors.grey[300],
                            isDense: true,
                            border: InputBorder.none,
                            labelText: 'Password',
                            labelStyle: const TextStyle(
                              fontSize: 14,
                              color: Colors.black,
                            ),
                            hintStyle: const TextStyle(
                                color: Colors.grey, fontSize: 10)),
                        style: const TextStyle(fontSize: 14),
                      ),
                    ),
                    const SizedBox(
                      height: 35.0,
                    ),
                    MaterialButton(
                      elevation: 0,
                      color: Colors.black87,
                      textColor: Colors.white,
                      child: const SizedBox(
                        height: 50,
                        child: Center(
                          child: Text(
                            'Login',
                            style: TextStyle(
                              fontSize: 18.0,
                              fontFamily: 'Brand Bold',
                            ),
                          ),
                        ),
                      ),
                      onPressed: () {
                        LoginAuthUser(context);
                      },
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(17),
                      ),
                    ),
                    const SizedBox(height: 20),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text(
                          'Do\'t have account ? ',
                          style: TextStyle(color: Colors.grey),
                        ),
                        GestureDetector(
                          onTap: () {
                            Navigator.pushNamed(
                                context, RegisterScreen.idScreen);
                          },
                          child: Text(
                            'Register now',
                            style: TextStyle(color: Colors.blue.shade900),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  final FirebaseAuth? firebaseAuth = FirebaseAuth.instance;


  void LoginAuthUser(BuildContext context) async {
    showDialog(
        context: context,
        builder: (BuildContext context) => ProgressDialog(
              message: 'Authenticating,please wait..',
            ),
        barrierDismissible: false
    );
    final UserCredential firebaseUser = await (firebaseAuth!
        .signInWithEmailAndPassword(
      email: emailController.text,
      password: passwordController.text,
    )
        .catchError((error) {
      Navigator.pop(context);
      Fluttertoast.showToast(msg: 'error : $error');
    }));
    final User? user = firebaseAuth?.currentUser;
    final uid = user?.uid;
    if (firebaseUser != null) {
      userRef.child(uid!).once().then((snap) {
        if (snap.snapshot.value != null) {
          Navigator.pushNamedAndRemoveUntil(
              context, MainScreen.idScreen, (route) => false);
          Fluttertoast.showToast(msg: 'Logged-in ');
        } else {
          Navigator.pop(context);
          firebaseAuth!.signOut();
          Fluttertoast.showToast(msg: 'No Record exist ');
        }
      });
    } else {
      Navigator.pop(context);
      Fluttertoast.showToast(msg: 'error ');
    }
  }
}

class TextFieldContainer extends StatelessWidget {
  final Widget? child;
  const TextFieldContainer({
    Key? key,
    this.child,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 10),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
      width: size.width * 0.8,
      decoration: BoxDecoration(
        color: const Color(0xFFEDEAEE),
        borderRadius: BorderRadius.circular(10),
      ),
      child: child,
    );
  }
}
