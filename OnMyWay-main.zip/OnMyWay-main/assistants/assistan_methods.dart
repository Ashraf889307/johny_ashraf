import 'dart:convert';
import 'dart:math';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:provider/provider.dart';
import 'package:rider_app/all_widgets/constants.dart';
import 'package:rider_app/assistants/request_assistant.dart';
import 'package:rider_app/data_handler/app_data.dart';
import 'package:rider_app/models/address.dart';
import 'package:rider_app/models/all_users.dart';
import 'package:rider_app/models/direct_details.dart';
import 'package:http/http.dart' as http;

class AssistantMethods {
  static Future<dynamic> searchAssistantAddress(
      Position position, context) async {
    String placeAddress = '';
    String? st1;
    //String? st2;
    String? st3;
    String? st4;

    String url =
        'https://maps.googleapis.com/maps/api/geocode/json?latlng=${position.latitude},${position.longitude}&key=$mapKey';

    var response = await RequestAssistant.getRequest(url);
    if (response != 'failed') {
      st1 = response['results'][0]['address_components'][3]['long_name'];
      //st2 = response['results'][0]['address_components'][3]['long_name'];
      st3 = response['results'][0]['address_components'][2]['long_name'];
      st4 = response['results'][0]['address_components'][1]['long_name'];

      placeAddress = st1! + "-" + st3! + "-" + st4!;

      //placeAddress = response['results'][0]['address_components'][3]['long_name'];

      Address userPickUpAddress = Address();
      userPickUpAddress.longitude = position.longitude;
      userPickUpAddress.latitude = position.latitude;
      userPickUpAddress.placeName = placeAddress;
      Provider.of<AppData>(context, listen: false)
          .updatePickUpLocationAddress(userPickUpAddress);
    }
    return placeAddress;
  }

  static void getCurrentOnlineUserInfo() async {
    firebaseUser = await FirebaseAuth.instance.currentUser;
    var userId = firebaseUser?.uid;
    DatabaseReference reference =
        FirebaseDatabase.instance.reference().child("users").child("${userId}");
    reference.once().then((dataSnapshot) {
      if (dataSnapshot.snapshot.value != null) {
        userCurrentInfo = Users.fromSnapshot(dataSnapshot);
      }
    });
  }
}
