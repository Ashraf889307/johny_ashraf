import 'dart:io';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:rider_app/models/address.dart';

class AppData extends ChangeNotifier {
  var mapType = MapType.normal;
  Address? pickUpLocation, dropOfLocation;

  late bool _isOnline;
  bool get isOnline => _isOnline;
  void updatePickUpLocationAddress(Address pickUpAddress) {
    pickUpLocation = pickUpAddress;
    notifyListeners();
  }

  void updateDropOfLocationAddress(Address dropOdAddress) {
    dropOfLocation = dropOdAddress;
    notifyListeners();
  }

  updateGoogleMapsShape(MapType type) {
    mapType = type;
    notifyListeners();
  }
}
