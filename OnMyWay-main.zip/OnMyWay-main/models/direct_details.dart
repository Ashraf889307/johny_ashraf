class DirectionsDetails {
  int? distanceValue;
  int? durationValue;
  String? distanceText;
  String? durationText;
  dynamic enCodePoints;
  DirectionsDetails({
    this.distanceValue,
    this.durationValue,
    this.distanceText,
    this.durationText,
    this.enCodePoints,
  });
}
