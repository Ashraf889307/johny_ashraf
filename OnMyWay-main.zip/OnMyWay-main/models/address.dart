class Address {
  String? placeFormattedAddress;
  String? placeName;

  String? placeId;
  dynamic latitude;
  dynamic longitude;

  Address({
    this.placeFormattedAddress,
    this.placeName,
    this.placeId,
    this.latitude,
    this.longitude,
  });
}
