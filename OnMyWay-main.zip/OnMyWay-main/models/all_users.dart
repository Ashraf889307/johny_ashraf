import 'package:firebase_database/firebase_database.dart';

class Users {
  String? id;
  String? email;
  String? name;
  String? phone;
  Users({
    this.id,
    this.email,
    this.name,
    this.phone,
  });
  Users.fromSnapshot(DatabaseEvent dataSnapshot) {
    id = dataSnapshot.snapshot.key;
    email = (dataSnapshot.snapshot.value as Map)["email"];

    name = (dataSnapshot.snapshot.value as Map)['name'];

    phone = (dataSnapshot.snapshot.value as Map)['phone'];
  }
}
