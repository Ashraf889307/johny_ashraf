import 'package:flutter/material.dart';
import 'package:rider_app/all_widgets/constants.dart';

Widget buildButton(
    {elevation, color, textColor, required text, required onPressed}) {
  return MaterialButton(
    elevation: elevation,
    color: color,
    textColor: textColor,
    child: SizedBox(
      height: 50,
      child: Center(
        child: Text(
          text,
          style: const TextStyle(fontSize: 18.0, fontFamily: 'Brand Bold'),
        ),
      ),
    ),
    onPressed: onPressed,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(17),
    ),
  );
}

Widget buildDivider() {
  return const Divider(
    height: 1.0,
    color: grey,
    thickness: 1.0,
  );
}
