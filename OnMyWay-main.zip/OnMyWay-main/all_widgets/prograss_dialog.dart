import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';


class ProgressDialog extends StatelessWidget {
  String? message;
  ProgressDialog({Key? key, this.message}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return const Center(
      child: CircularProgressIndicator(
        color: Colors.black,
        strokeWidth: 2,
      ),
    );
  }
}
