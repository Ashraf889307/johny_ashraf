import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:rider_app/models/all_users.dart';

///configuration
const String mapKey = 'AIzaSyDZIQNS1XVa8r_usSFJWOdumY2hV4OOOdw';
User? firebaseUser;
Users? userCurrentInfo;

String serverToken =
    'key=AAAA_eaNpZA:APA91bE_vmWAGDLhiQe1AC3loo4Ll7MHVuQc19HAwqWKc4nEJsUw4liUTzs6nwoELZmrg1CR34BGDmlafTwQixbWLCAu8MjUJBR6opGr2xgTkULG90BLX4wqEu24m8c4MmuZ9q_Meelw';
int driverRequestTimeOut=40;
String statusRide='';
String rideStatus='Driver is coming';
String carDetailsDriver='';
String driverName='';
String driverPhone='';
double starCounter=0.0;
String title='';
String carRideType='';
///Theme
const Color white = Colors.white;
const Color black = Colors.black;
const Color black54 = Colors.black54;
const Color deepPurple = Colors.deepPurple;
const Color blueAccent = Colors.blueAccent;
Color? tealAccent100 = Colors.tealAccent[100];
const Color grey = Colors.grey;
const Color red = Colors.red;
const Color yellow = Colors.yellow;
const Color yellowAccent = Colors.yellowAccent;
